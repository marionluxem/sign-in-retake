const signIn = {
  template: `
    Name: <input type="text" ng-model="info.name">
    Password: <input type="text" ng-model="info.password">
    <button type="button" ng-click="$ctrl.setInfo(info);">Submit</button>
  `,
  controller: function(SignInService) {
    const vm = this;
    vm.setInfo = (info) => {
      SignInService.setInfo(info);
    };
  }
};
angular
.module("app")
.component("signIn", signIn);