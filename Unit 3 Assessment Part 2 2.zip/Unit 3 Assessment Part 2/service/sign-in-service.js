"use strict";

// function signInService()  {

//     const service = this;
//     service.SignInService = (info) => {
//         setInfo = value;
//         console.log(setInfo);
//         console.log(info);
//   }
    
// angular
//   .module("ServiceApp")  // tells it what module/app it is a part of
//   .service("SignInService", signInService);}  // defines the name of the service


function SignInService() {
    const self = this;
    self.setInfo = (data) => {
      self.info = data;
      console.log(self.info);
    };
  }
  angular
  .module("app")
  .service("SignInService", SignInService);